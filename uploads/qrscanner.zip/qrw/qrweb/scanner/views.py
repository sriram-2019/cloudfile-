import cv2
import numpy as np
import base64
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def qr_scanner(request):
    """Renders the QR scanner page."""
    return render(request, "qr_scanner.html")

@csrf_exempt
def qr_redirect(request):
    """Handles QR code scanning and redirects accordingly."""

    if request.method == "POST":
        data_url = request.POST.get("image")
        source = request.POST.get("source", "unknown")

        if not data_url:
            return JsonResponse({"status": "error", "message": "No image data received."})

        try:
            if "," in data_url:
                _, encoded = data_url.split(",", 1)
            else:
                return JsonResponse({"status": "error", "message": "Invalid image format."})

            image_data = base64.b64decode(encoded)
            np_arr = np.frombuffer(image_data, np.uint8)

            if np_arr.size == 0:
                return JsonResponse({"status": "error", "message": "Decoded image is empty."})

            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            if frame is None:
                return JsonResponse({"status": "error", "message": "Failed to decode image."})

            # QR Code Detection
            qr_detector = cv2.QRCodeDetector()
            decoded_data, points, _ = qr_detector.detectAndDecode(frame)

            if decoded_data:
                print(f"Scanned QR Code URL: {decoded_data}")
                print(f"Source: {source}")

                # Redirect logic
                if source == "qr_app":
                    return JsonResponse({"status": "success", "url": "https://secretweb.pythonanywhere.com/"})
                    return JsonResponse({"status": "success", "url": "https://chatgpt.com"})

            else:
                return JsonResponse({"status": "no_qr", "message": "No QR Code detected."})

        except Exception as e:
            return JsonResponse({"status": "error", "message": f"Exception: {str(e)}"})

    return JsonResponse({"status": "error", "message": "Invalid request method."})
